URL_LIST = [
'https://www.titan.fitness/strength/dumbbells/rubber-coated-hex/75-lb-rubber-hex-dumbbells/421076.html',
'https://www.titan.fitness/strength/dumbbells/rubber-coated-hex/80-lb-rubber-hex-dumbbells/421081.html',
'https://www.titan.fitness/strength/dumbbells/rubber-coated-hex/85-lb-rubber-hex-dumbbells/421086.html',
'https://www.titan.fitness/strength/dumbbells/rubber-coated-hex/90-lb-rubber-hex-dumbbells/421091.html',
'https://www.titan.fitness/strength/dumbbells/rubber-coated-hex/95-lb-rubber-hex-dumbbells/421096.html',
'https://www.titan.fitness/strength/dumbbells/rubber-coated-hex/100-lb-rubber-hex-dumbbells/421101.html',
'https://www.titan.fitness/strength/specialty-machines/lower-body/indoor-tire-flipping-machine/401136.html'
]